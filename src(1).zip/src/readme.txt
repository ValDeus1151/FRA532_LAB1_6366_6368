Install package by bash file:
$ source install.bash

Run Simulation (world+robot in Gazebo):
$ ros2 launch ur5_ros2_gazebo ur5_simulation.launch.py
$ ros2 launch carver_navigation vmegarover_navigation.launch.py 
